from google.cloud.functions_v1.context import Context
from typing import List

from api.models.event import Event
from api.repository import Bucket
from api.repository import Firestore
from api.repository import PubSub
from api.repository import Repository
from api.models.contract import IngestionContract


def main() -> None:
# def main(raw: dict) -> None:
    """Código de entrada da function.

    Responsável por manipular o fluxo geral da aplicação.

    Args:
        raw (dict): json representando o contrato a ser processado.
    """
    # event = Event(**raw)
    # bucket = Bucket()
    # contract = bucket.get('dougras/new_contract.json')
    # print(contract)

    contract = IngestionContract(**{
        "ConfigDataflow": {
            "PipelineOptions": {
            "NmTabela": "dbcart.dbo.tbcontrolearquivo",
            "NmDatasetDestino": "dbcart_dbo",
            "NmProjeto": "oceanic-cache-349523",
            "FlCargaFull": True,
            "NmDatabase": "SQL_SERVER",
            "DsHost": "127.0.0.1",
            "NuPorta": 2500,
            "DsPointerField": "DtInclusao",
            "DsChaveAcesso": "arqd-mssql-pwd-transanlt_batch-oceanic-cache-349523",
            "NmChaveAcesso": "arqd-mssql-usr-transanlt_batch-oceanic-cache-349523"
            },
            "Infra": {
                "NmBigQuery": "general-purpose-bucket-dougras"
            }
        },
        "ConfigAirflow": {
            "DsCronScheduler": "00 17 * * *"
        },
        "ConfigBigQuery": {
            "NmParticaoTrusted": "DtInclusao",
            "NmTabelaWork": "oceanic-cache-349523.work_dbcart_dbo.tbcontrolearquivo",
            "LstChavesTrusted": ["CdControleArquivo"]
        }
    })
    print(contract.dict(by_alias=True))

    # repositories: List[Repository] = [Firestore(), PubSub()]
    # for repository in repositories:
    #     repository.save(contract)


main()

# def wrapper(raw: dict, context: Context):
#     try:
#         main(raw, context)
#     except Exception as error:
#         raise RuntimeError(
#             f'Execution failed with error: {str(error)}') from error

