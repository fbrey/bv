from enum import Enum

from environ import config
from environ import var


class Environment(str, Enum):
    """Representa todos os ambientes possíveis."""
    DES = 'DES'
    QA = 'QA'
    UAT = 'UAT'
    PRD = 'PRD'
    LOCAL = 'LOCAL'


@config
class Config:
    """Classe de configuração de variáveis de ambiente.

    Tem como objetivo armazenar e validar todas as variáveis de ambiente
    necessárias na aplicação.
    """

    ENVIRONMENT: str = var(converter=Environment)
    PROJECT_ID: str = var()
    # REGION: str = var(default='southamerica-east1')

    FUNCTION_VERSION: str = var()
    DAG_VERSION: str = var()
    # DATAFLOW_VERSION: str = var()

    TRIGGER_BUCKET: str = var()
    PUBSUB_TOPIC: str = var()

    # SECRET_MANAGER_PROJECT_ID: str = var()
    # SUBNETWORK_TAGS: str = var()
    # SUBNETWORK: str = var()

    # AIRFLOW_EMAILS: List[str] = var(converter=string_to_list_of_strings)
    FIRESTORE_COLLECTION_NAME: str = var()

    # ACCESS_KEY_DESCRIPTION = var()
    # ACCESS_KEY_NAME = var()


CONFIG: Config = Config.from_environ()  # type: ignore
