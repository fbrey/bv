from abc import ABC
from abc import abstractmethod
import json

from config import CONFIG
from factory import ModelFactory
from google.cloud import firestore
from google.cloud import pubsub_v1
from google.cloud import storage
from models.contract import BaseContract
from models.dataflow import Dataflow
from models.application import Application
from models.bigquery import BigQuery
from utils import ContractType
from utils import ModelType


class Repository(ABC):
    """Classe base de todos os repositórios."""

    @abstractmethod
    def save(self, contract: BaseContract) -> None:
        """Método abstrato para salvar os contratos.

        Args:
            contract (BaseContract): contrato que deve ser salvo.

        Raises:
            NotImplementedError: _description_
        """
        raise NotImplementedError()

    @abstractmethod
    def get(self, identifier: str) -> BaseContract:
        """Método abstrato para recuperar os contratos.

        Args:
            identifier (str): identificador do contrato.

        Raises:
            NotImplementedError: _description_

        Returns:
            BaseContract: modelo de objeto que representa o contrato.
        """
        raise NotImplementedError()


class Firestore(Repository):
    """Repositório com conexão ao Firestore."""

    def __init__(self) -> None:
        self.conn = firestore.Client()
        self.collection = self.conn.collection(
            CONFIG.FIRESTORE_COLLECTION_NAME, )

    def save(self, contract: BaseContract) -> None:
        """Salva um contrato no Firestore.

        Args:
            contract (BaseContract): instância do contrato que vai ser salvo
        """
        document = self.collection.document(contract.firestore_key)
        document.set(contract.dict(by_alias=True))

    def get(self, identifier: str) -> BaseContract:
        """Recupera um contrato do Firestore.

        Args:
            identifier (str): firestore_key do objeto que será recuperado.

        Returns:
            BaseContract: modelo representando o contrato.
        """
        reference = self.collection.document(identifier)
        document = reference.get()
        as_dict = document.to_dict()

        contract_type = as_dict['ConfigAirflow'].get('DsTipoCarga',
                                                     ContractType.INGESTION)
        factory = ModelFactory(contract_type)

        return factory.create(ModelType.CONTRACT, **as_dict)


class PubSub(Repository):
    """Repositório com conexão ao PubSub."""

    def __init__(self) -> None:
        self.publisher = pubsub_v1.PublisherClient()
        self.subscriber = pubsub_v1.SubscriberClient()

    def save(self, contract: BaseContract) -> None:
        """Publica um contrato no PubSub.

        Args:
            contract (BaseContract): instância do contrato que será publicado.
        """
        encoded = contract.json(by_alias=True).encode('utf-8')
        future = self.publisher.publish(contract.publish_topic_path, encoded)
        future.result()

    def get(self, identifier: str) -> BaseContract:
        """Retorna o último contrato recebido no tópico `identifier`.

        Args:
            identifier (str): nome do tópico para se inscrever.

        Returns:
            BaseContract: instância do último contrato publicado.
        """
        with self.subscriber:
            response = self.subscriber.pull(request={
                'subscription':
                self.subscriber.subscription_path(
                    CONFIG.PROJECT_ID,
                    identifier,
                ),
                'max_messages':
                1,
            }, )

        encoded: bytes = response.received_messages.pop().message.data
        decoded = encoded.decode('utf-8')
        as_dict = json.loads(decoded)

        contract_type = as_dict['ConfigAirflow'].get('DsTipoCarga',
                                                     ContractType.INGESTION)
        factory = ModelFactory(contract_type)

        return factory.create(ModelType.CONTRACT, **as_dict)


class Bucket(Repository):
    """Publica um contrato no Bucket."""

    def __init__(self) -> None:
        client = storage.Client()
        self.conn = client.bucket(
            CONFIG.TRIGGER_BUCKET,
            user_project=CONFIG.PROJECT_ID,
        )

    def save(self, contract: BaseContract) -> None:
        """Salva um contrato no Bucket.

        Args:
            contract (BaseContract): contrato que será persistido no Bucket.
        """
        blob = self.conn.blob(contract.bucket_key)
        blob.upload_from_string(contract.json(by_alias=True))

    def get(self, identifier: str) -> BaseContract:
        """Recupera um arquivo do bucket.

        O arquivo raw que está no bucket será recuperado
        e retornado como uma instância do modelo `BaseContract`.

        Args:
            identifier (str): file path para o arquivo a ser recuperado.

        Returns:
            BaseContract: modelo instânciado do arquivo recuperado.
        """
        blob = self.conn.get_blob(identifier)
        file: dict = json.loads(blob.download_as_string().decode('utf-8'))
        config_dataflow = file.get('ConfigDataflow')
        config_airflow = file.get('ConfigAirflow')
        config_application = file.get('ConfigApplication') if file.get('ConfigApplication') else {}
        config_big_query = file.get('ConfigBigQuery')

        contract_type = config_airflow.get(
            'DsTipoCarga',
            ContractType.INGESTION,
        )
        factory = ModelFactory(contract_type)
        pipeline = factory.create(ModelType.PIPELINE, **config_dataflow.get('PipelineOptions'))
        config_dataflow['PipelineOptions'] = pipeline

        dataflow = Dataflow(**config_dataflow)
        airflow = factory.create(ModelType.AIRFLOW, **config_airflow)
        application = Application(**config_application)
        big_query = BigQuery(**config_big_query)        

        contract = factory.create(
            ModelType.CONTRACT,
            dataflow=dataflow,
            airflow=airflow,
            application=application,
            big_query=big_query
        )
        return contract
