from datetime import datetime

from pydantic import BaseModel
from pydantic import Field


class Event(BaseModel):
    bucket: str
    content_type: str = Field(alias='contentType')
    crc32c: str
    etag: str
    generation: int
    id: str
    kind: str
    md5_hash: str = Field(alias='md5Hash')
    media_link: str = Field(alias='mediaLink')
    metageneration: int
    file_path: str = Field(alias='name', regex=r'.+\.json$')
    self_link: str = Field(alias='selfLink')
    size: int
    storage_class: str = Field(alias='storageClass')
    time_created: datetime = Field(alias='timeCreated')
    time_storage_class_updated: datetime = Field(
        alias='timeStorageClassUpdated')
    updated: datetime

    @property
    def file_name(self) -> str:
        """Gera o nome do arquivo.

        Reliza um split no path recebido e retorna somente o nome do arquivo.

        Returns:
            str: nome do arquivo.
        """
        return self.file_path.split('/')[-1]
