from abc import abstractmethod
from typing import Optional
from typing import List
from abc import ABC

from pydantic import BaseModel, Field
from pydantic import validator

from utils import SchemaField


class File(BaseModel):
  connection_name: str = Field(alias='Nmconexao')
  remote_path: str = Field(alias='RemotePath')
  file_bucket_destination: str = Field(alias='FileNmBucketDestino')
  file_compression: bool = Field(alias='FileCompressao', default=False)
  file_schema_fields: List[SchemaField] = Field(alias='FileSchemaFields', default=[])
  field_delimiter: str = Field(alias='CSVDelimiter', default=';')
  file_skip_leading_rows: int = Field(alias='CSVSkipLeadingRows', default=0)
  source_uri: Optional[str] = Field(alias='DsSourceURILanding')
  hostname: str = Field(alias='NmHostname')