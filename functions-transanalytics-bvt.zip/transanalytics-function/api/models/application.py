from pydantic import Field

from utils import ModelPopulatedByFieldName


class Application(ModelPopulatedByFieldName):
  cloud_function_version: str = Field(alias='DsVersaoCloudFunction', default='1.2.6')
  dag_template_version: str = Field(alias='DsVersaoDagTemplate', default='1.2.0')