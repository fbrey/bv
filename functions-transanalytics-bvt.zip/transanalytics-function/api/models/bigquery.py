from typing import List, Optional
from pydantic import Field, validator
from utils import ModelPopulatedByFieldName, PartitionType


class BigQueryInfra(ModelPopulatedByFieldName):
	source_uri: Optional[str] = Field(alias='DsSourceURI')
	source_uri_prefix: Optional[str] = Field(alias='DsSourceURIPrefix')

class BigQuery(ModelPopulatedByFieldName):
	trusted_partition: str = Field(alias='NmParticaoTrusted')
	trusted_table: Optional[str] = Field(alias='NmTabelaTrusted')
	work_table: str = Field(alias='NmTabelaWork')
	infra: BigQueryInfra = Field(alias='Infra', default=BigQueryInfra())
	trusted_keys: List[str] = Field(alias='LstChavesTrusted')

	big_query_conn: str = Field(alias='NmBigQueryConn', default='bigquery_default')
	partition_type: str = Field(alias='DsTipoParticao', default='DAY')
	clustering_fields: List = Field(alias='LstCamposClusterizacao', default=[])

	@validator('partition_type')
	def convert_partition_type_to_english(cls, partition_type: PartitionType) -> str:
		"""Validação do `partition_type`.

		A `partition_type` é recebida em português mas deve ser
		retornada em inglês.

		Args:
			partition_type (PartitionType): _description_

		Returns:
			str: _description_
		"""
		partition_types = {
			PartitionType.HOUR: 'HOUR',
			PartitionType.DAY: 'DAY',
			PartitionType.MONTH: 'MONTH',
			PartitionType.YEAR: 'YEAR',
			'': ''
		}

		return partition_types[partition_type]


	@validator('clustering_fields')
	def validate_clustering_fields_is_not_empty(cls, fields: str) -> List[str]:
		"""Validação do custering_fields.

		Existe uma regra de negócio que diz que os campos do `clustering_fields`
		não deve ser vazios. Esse validator remove qualquer valor que possa ser
		considerado inválido.

		Args:
			fields (str): fields passados como parâmetros.

		Returns:
			List[str]: lista com os fields válidos.
		"""
		return [field for field in fields if field]
