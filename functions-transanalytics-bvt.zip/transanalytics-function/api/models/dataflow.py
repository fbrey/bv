from abc import ABC
from datetime import datetime
from typing import List
from typing import Optional

from config import CONFIG
from pydantic import BaseModel
from pydantic import EmailStr
from pydantic import validator
from pydantic import Field
from pydantic import root_validator
from utils import ModelPopulatedByFieldName
from utils import SchemaField
    

class DataflowInfra(BaseModel):
    big_query_name: str = Field(alias='NmBigQuery')

    region: str = Field(alias='DsRegiaoDefault', default='us-east1')
    workers: int = Field(alias='NuDefaultWorkers', default=1)
    max_workers: int = Field(alias='NuMaxWorkers', default=1)
    subnetwork: Optional[str] = Field(alias='DsSubnetwork')
    instance: str = Field(
        alias='DsInstancia',
        default='n1-standard-1',
        regex=r'^(?<![a-z0-9])[a-z0-9]{2,4}(?![a-z0-9])-standard-[0-9]{1,3}$'
    )
    email: Optional[EmailStr] = Field(alias='DsEmail')
    network_tags: Optional[str] = Field(alias='DsNetworkTags')
    template_version: str = Field(alias='DsVersaoDataflowTemplate', default='1.1.0')
    path_flex_template: Optional[str] = Field(alias='DsCaminhoFlexTemplate')
    temporary_location: Optional[str] = Field(alias='DsTempLocation')
    stage_location: Optional[str] = Field(alias='DsStageLocation')
    timeout_job: int = Field(alias='NuTimeoutJobDataflow', default=18000)
    url_job: Optional[str] = Field(alias='DsURLJobDataflow')
    poke_interval: int = Field(alias='NuIntervaloPoke', default=30)


class PipelineOptions(ModelPopulatedByFieldName, ABC):
    table_name: str = Field(alias='NmTabela')
    target_dataset_name: str = Field(alias='NmDatasetDestino')
    target_table_name: Optional[str] = Field(alias='NmTabelaDestino')
    full_load: bool = Field(alias='FlCargaFull')
    database_name: str = Field(alias='NmDatabase')
    host: str = Field(alias='DsHost', regex=r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$')
    port: int = Field(alias='NuPorta')
    pointer_field: str = Field(alias='DsPointerField')

    project_name: str = Field(alias='NmProjeto')
    parallel: bool = Field(alias='FlParalelismoResult', default=False)
    secret_manager_id: str = Field(alias='NmProjetoSecretManager', default='bv-si-si-siem-prd')
    access_key_password: str = Field(alias='DsChaveAcesso')
    access_key_name: str = Field(alias='NmChaveAcesso')
    prefix_output_file: Optional[str] = Field(alias='DsPrefixoArquivoSaida')
    quantity_output_files: int = Field(alias='QtArquivoSaida', default=1)
    output_directory: Optional[str] = Field(alias='DsDiretorioSaida')
    datalake_project: Optional[str] = Field(alias='NmProjetoDatalake')


    @validator('target_dataset_name')
    def add_work_to_target_dataset_name(cls, target_dataset_name: str) -> str:
        """Validação do `target_dataset_name`.

        Concatena o prefixo "work_" no `target_dataset_name`.

        Args:
            target_dataset_name  (str): nome do dataset recebido.

        Returns:
            str: nome do dataset concatenado com o prefixo "_work".
        """
        if target_dataset_name[:5] == 'work_':
            return target_dataset_name
        return f'work_{target_dataset_name}'

    @property
    def job_name(self) -> str:
        """Gera o nome do job.

        Cria um nome para o job utilizando o prefixo "ingestion",
        o nome da tabela com os underlines substituídos por hífens e
        a data atual.

        Returns:
            str: nome da tabela.
        """
        now = datetime.now().strftime("%Y%m%d-%H%M%S")
        fixed_target_table_name = self.target_table_name.replace('_', '-')
        return f'ingestion-{fixed_target_table_name}-{now}'

    @property
    def work_table(self) -> str:
        """Gera o nome da tabela work.

        Cria o nome da tabela work usando o `datalake_project`,
        `target_dataset_name` e `target_table_name`.

        Returns:
            str: nome da tabela work.
        """
        return f'{self.datalake_project}.{self.target_dataset_name}.{self.target_table_name}'

    @property
    def trusted_table(self) -> str:
        """Gera o nome da tabela trusted.

        Cria o nome da tabela trusted, removendo o prefixo "work_" do `target_dataset_name`,
        e concatenando esse resultado com `datalake_project` e `target_table_name`.

        Returns:
            str: _description_
        """
        dataset_name_without_work = self.target_dataset_name.replace(
            'work_', '')
        return f'{self.datalake_project}.trusted_{dataset_name_without_work}.{self.target_table_name}'

    @property
    def source_uri_prefix(self) -> str:
        """Gera o path do arquivo.

        Faz um split na "/" do path e retorna caminho para a pasta
        que se encontra o arquivo.

        Returns:
            str: path da pasta.
        """
        return self.output_directory if self.output_directory[
            -1:] == '/' else f'{self.output_directory}/'

    @property
    def source_uri(self) -> str:
        """Gera path para todos arquivos.

        Cria um path para todos os arquivos que se encontram na
        pasta adicionando "*" no final do path.

        Returns:
            str: path para todos arquivos.
        """
        return f'{self.source_uri_prefix}*'

    @property
    def underscore_table_name(self) -> str:
        """Gera nome da tabela com underscore.

        Substitui os "." da tabela por "_".

        Returns:
            str: nome da tabela com underscore.
        """
        return self.table_name.replace('.', '_')

    @property
    def datalake_name(self) -> str:
        """Gera o nome do datalake.

        Concatena 'bv-datalake' + {CONFIG.ENVIRONMENT} + '01'

        Returns:
            str: nome do datalake
        """
    
    @property
    def environment_lower(self) -> str:
        """Retorna o environemnt atual em lower case.

        Returns:
            str: environment lower case.
        """
        return CONFIG.ENVIRONMENT.lower()



class ReprocessingPipeline(PipelineOptions):
    extraction_filter: str = Field(alias='DsFiltroExtracao')


class IngestionPipeline(PipelineOptions):
    ...


class Dataflow(ModelPopulatedByFieldName):
    pipeline: PipelineOptions = Field(alias='PipelineOptions')
    infra: DataflowInfra = Field(alias='Infra')

