from abc import abstractmethod

from typing import Optional

from config import CONFIG
from models.airflow import BaseAirflow
from models.dataflow import Dataflow
from models.file import File
from models.application import Application
from models.bigquery import BigQuery
from pydantic import Field
from pydantic import root_validator
from utils import ModelPopulatedByFieldName
from utils import ContractType
from utils import update_attributes


class BaseContract(ModelPopulatedByFieldName):
    airflow: BaseAirflow = Field(alias='ConfigAirflow')
    dataflow: Dataflow = Field(alias='ConfigDataflow')
    application: Application = Field(alias='ConfigApplication', default=Application())
    big_query: BigQuery = Field(alias='ConfigBigQuery')
    file: Optional[File] = Field(alias='ConfigFile')

    @root_validator()
    def generate_optional_parameters(cls, values: dict):
        """Gera automaticamente os atributos de campos opcionais a partir
		de variáveis de ambiente e/ou parametros obrigatorios.

		Args:
			values (dict): parâmetros do contrato.

		Returns:
			dict: parâmetros do contrato modificados.
		"""
        dataflow: Dataflow = values['dataflow']
        big_query: BigQuery = values['big_query']
        airflow: BaseAirflow = values['airflow']
        

        target_dataset_name =  dataflow.pipeline.target_dataset_name
        database_name = dataflow.pipeline.database_name
        table_name = dataflow.pipeline.table_name
        template_version = dataflow.infra.template_version
        region = dataflow.infra.region

        environment_lower = CONFIG.ENVIRONMENT.lower()
        target_table_name = table_name.split('.')[-1]
        target_table_name_lower = target_table_name.lower()
        source = database_name.lower().replace('_', '')
        instance_prefix = target_dataset_name.split('_')[1]
        instance_sufix = '_'.join(target_dataset_name.split('_')[2:])
        project_name = dataflow.pipeline.project_name
        # datalake_name = f'bv-datalake{environment_lower}01'
        source_uri_prefix = f'gs://{dataflow.infra.big_query_name}/raw/{source}/{instance_prefix}/{instance_sufix}/{target_table_name_lower}'

        if 'file' in values.keys():
            file: File = values['file']
            if airflow.load_type == ContractType.INGESTAO_SFTP:
                file.source_uri = f'landing-zone/sftp/{target_dataset_name}/{target_table_name}'
            elif airflow.load_type == ContractType.INGESTAO_SSH:
                file.source_uri = f'landing-zone/ssh/{target_dataset_name}/{target_table_name}'

        update_attributes(dataflow.pipeline, {
            'output_directory': f'gs://{dataflow.infra.big_query_name}/raw/{source}/{instance_prefix}/{instance_sufix}/{target_table_name_lower}',
            'prefix_output_file': target_table_name_lower,
            'datalake_project': project_name,
            'target_table_name': target_table_name_lower
        })

        update_attributes(dataflow.infra, {
            'subnetwork': f'https://www.googleapis.com/compute/v1/projects/network-bv/regions/{region}/subnetworks/sub-{environment_lower}',
            'email': f'sa-arqd-anlt-batch-{environment_lower}-transan@{project_name}.iam.gserviceaccount.com',
            'network_tags': f'{environment_lower};internet;padrao',
            'path_flex_template': f'gs://{project_name}/dataflow/templates/templatedataflow-arqd-base-motor-ingestao-{template_version}.json',
            'temporary_location': f'gs://{project_name}/dataflow/temp/',
            'stage_location': f'gs://{project_name}/dataflow/staging/',
            'url_job': f'https://dataflow.googleapis.com/v1b3/projects/{project_name}/locations/{region}/jobs/'
        })

        update_attributes(big_query, {
            'trusted_table': dataflow.pipeline.trusted_table,
            'work_table': dataflow.pipeline.work_table
        })

        update_attributes(big_query.infra, {
            'source_uri': f'{source_uri_prefix}/*',
            'source_uri_prefix': f'{source_uri_prefix}/'
        })

        return values

    @property
    @abstractmethod
    def firestore_key(self) -> str:
        """Método abstrato para gerar o identificador do arquivo no Firestore.

        Raises:
            NotImplementedError: _description_

        Returns:
            str: identificador do arquivo no Firestore.
        """
        raise NotImplementedError()

    @property
    def publish_topic_path(self) -> str:
        """Tópico para publicar o contrato.

        Returns:
            str: tópico no PubSub.
        """
        return f'projects/{CONFIG.PROJECT_ID}/topics/{CONFIG.PUBSUB_TOPIC}'

    @property
    def subscribe_topic_name(self) -> str:
        """Tópico para recuperar o contrato.

        Returns:
            str: tópico no PubSub.
        """
        return f'{CONFIG.PUBSUB_TOPIC}-sub'

    @property
    def bucket_key(self) -> str:
        """Gera o identificador do arquivo no Bucket.

        Returns:
            str: identificador do arquivo.
        """
        return f'{CONFIG.PROJECT_ID}_{self.airflow.start_date}.json'


class IngestionContract(BaseContract):
    @property
    def firestore_key(self) -> str:
        """Implementação da firestore_key para contratos do tipo INGESTAO.

        Returns:
            str: identificador do arquivo no Firestore.
        """
        return self.dataflow.pipeline.underscore_table_name


class ReprocessingContract(BaseContract):
    @property
    def firestore_key(self) -> str:
        """Implementação da firestore_key para contratos do tipo REPROCESSAMENTO.

        Returns:
            str: identificador do arquivo no Firestore.
        """
        return f'{self.dataflow.pipeline.underscore_table_name}_{self.airflow.start_date_in_firestore_format}'
