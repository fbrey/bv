from __future__ import annotations

from abc import ABC
from typing import List, Optional

import pendulum
from pydantic import BaseModel
from pydantic import EmailStr
from pydantic import Field
from pydantic import root_validator
from utils import ContractType
from utils import CronTab


class BaseAirflow(BaseModel):
    cron_scheduler: str = Field(
        alias='DsCronScheduler',
        regex=r'^((((\d+,)+\d+|(\d+(\/|-|#)\d+)|\d+L?|\*(\/\d+)?|L(-\d+)?|\?|[A-Z]{3}(-[A-Z]{3})?) ?){5,7})$|(@(annually|yearly|monthly|weekly|daily|hourly|reboot))|(@every (\d+(ns|us|µs|ms|s|m|h))+)$'
    )

    updated: bool = Field(alias='FlModificado', default=True)
    owner: str = Field(alias='NmOwner', default='TransAnalytics')
    email: List[EmailStr] = Field(alias='DsEmail', default=[ 'jorge.ssilva@bv.com.br' ])
    start_date: Optional[str] = Field(
        alias='DtStartDate',
        regex=r'^\d{4}-\d{1,2}-\d{1,2} \d{2}:\d{2}:\d{2}$',
    )
    load_type: ContractType = Field(alias='DsTipoCarga', default=ContractType.INGESTION)

    @root_validator
    def setup_start_date(cls, values: dict) -> dict:
        """Inicialização da `start_date`.

        Esse validator calcula quando será a próxima data de ag'en'damento
        a partir do `cron_scheduler` informado.
        """
        load_type: ContractType = values['load_type']
        start_date: str = values['start_date']
        cron_scheduler: str = values['cron_scheduler']

        if not start_date:
            crontab = CronTab(cron_scheduler)
            start_date = crontab.next(
            ) if load_type == ContractType.REPROCESSING else crontab.previous(
            )
            values['start_date'] = start_date

        if cls == ReprocessingAirflow:
            values['cron_scheduler'] = '@once'

        return values

    @property
    def start_date_in_firestore_format(self) -> str:
        """Retorna a `start_date` no formato aceitado pelo Firestore."""
        return pendulum.parse(self.start_date).format('YYYYMMDDhhmmSS')


class ReprocessingAirflow(BaseAirflow):
    ...


class IngestionAirflow(BaseAirflow):
    ...
