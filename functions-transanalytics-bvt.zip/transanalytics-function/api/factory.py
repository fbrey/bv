from abc import ABC
from abc import abstractmethod

from models.airflow import BaseAirflow
from models.airflow import IngestionAirflow
from models.airflow import ReprocessingAirflow
from models.contract import IngestionContract
from models.contract import ReprocessingContract
from models.dataflow import IngestionPipeline
from models.dataflow import ReprocessingPipeline
from pypattyrn.creational.factory import AbstractFactory
from pypattyrn.creational.factory import Factory
from utils import ContractType
from utils import ModelType


class BaseFactory(Factory, ABC):
    """Classe base de todas as factories."""

    @property
    @abstractmethod
    def types(self) -> dict:
        """Mapa do nome do contrato para modelo.

        Raises:
            NotImplementedError: _description_

        Returns:
            dict: dicionario no seguinte formato `{ [ContractType, ContractModel]}`
        """
        raise NotImplementedError()

    def create(self, contract: ContractType, **params: dict) -> BaseAirflow:
        """Instância um modelo de contrato.

        Args:
            contract (ContractType): tipo do contrato a ser criado.

        Returns:
            BaseAirflow: instância do modelo.
        """
        instance = self.types[contract]
        return instance(**params)


class AirflowFactory(BaseFactory):
    """Implementação concreta da factory do airflow."""

    @property
    def types(self) -> dict:
        """Define os modelos do airflow.

        Returns:
            dict: retorna os modelos do airflow.
        """
        return {
            ContractType.INGESTION: IngestionAirflow,
            ContractType.REPROCESSING: ReprocessingAirflow
        }


class PipelineFactory(BaseFactory):
    """Implementação concreta da factory do pipeline."""

    @property
    def types(self) -> dict:
        """Define os modelos do pipeline.

        Returns:
            dict: retorna os modelos do pipeline.
        """
        return {
            ContractType.INGESTION: IngestionPipeline,
            ContractType.REPROCESSING: ReprocessingPipeline
        }


class ContractFactory(BaseFactory):
    """Implementação concreta da factory do contrato."""

    @property
    def types(self) -> dict:
        """Define os modelos do contrato.

        Returns:
            dict: retorna os modelos do contrato.
        """
        return {
            ContractType.INGESTION: IngestionContract,
            ContractType.REPROCESSING: ReprocessingContract
        }


class ModelFactory(AbstractFactory):
    """Implementação concreta da Factory."""

    def __init__(self, contract_type: ContractType):
        super().__init__()
        self.contract_type = contract_type

        # Just add new models and factories here
        self.setup = {
            ModelType.AIRFLOW: AirflowFactory,
            ModelType.PIPELINE: PipelineFactory,
            ModelType.CONTRACT: ContractFactory
        }

        for factory_class in self.setup.values():
            self._register(factory_class.__name__, factory_class())

        self.creators = {
            model_type: self._factories[factory.__name__].create
            for model_type, factory in self.setup.items()
        }

    def create(self, model_type: ModelType, **params: dict) -> BaseAirflow:
        """Cria um modelo.

        Args:
            model_type (ModelType): tipo do modelo que será criado.

        Returns:
            BaseAirflow: instância do modelo.
        """
        creator = self.creators[model_type]
        return creator(self.contract_type, **params)
