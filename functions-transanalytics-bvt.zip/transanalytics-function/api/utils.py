from enum import Enum
from logging import getLogger
from logging import INFO
from logging import Logger
from typing import Callable, List

from crontab import CronTab as _CronTab
from crontab._crontab import _increments
from google.cloud.logging import Client
import pendulum
from pendulum.datetime import DateTime
from pydantic import BaseModel
from pydantic import validator


class ContractType(str, Enum):
    """Representa todos os contratos possíveis."""
    INGESTION = 'INGESTAO'
    REPROCESSING = 'REPROCESSAMENTO'
    INGESTAO_SFTP = 'INGESTAO_SFTP'
    REPROCESSAMENTO_SFTP = 'REPROCESSAMENTO_SFTP'
    INGESTAO_SSH = 'INGESTAO_SSH'
    REPROCESSAMENTO_SSH = 'REPROCESSAMENTO_SSH'



class PartitionType(str, Enum):
    """Representa todos os tipos de partições possíveis."""
    HOUR = 'HORA'
    DAY = 'DIA'
    MONTH = 'MES'
    YEAR = 'ANO'


class ModelType(str, Enum):
    """Representa todos os modelos possíveis.

    Caso seja necessário adicionar mais um modelo o nome do mesmo deve
    ser adicionado aqui pois a factory `ModelFactory` se baseia nesse
    Enum.
    """
    AIRFLOW = 'AIRFLOW'
    PIPELINE = 'PIPELINE'
    CONTRACT = 'CONTRACT'


class ModelPopulatedByFieldName(BaseModel):
    """Classe utilizaria para ser usada nos modelos.

    Tem como objetivo permitir a população das instâncias através do
    alias configurado nos respectivos campos.
    """

    class Config:
        """Representa as configurações do `BaseModel`."""
        allow_population_by_field_name = True


class SchemaField(BaseModel):
    """Modelo dos campos SchemaField."""
    name: str
    type: str

    @validator('type')
    def transform_type_to_uppercase(type: str):
        '''Transforma o campo ´type´ para uppercase

        Args:
            type (str): tipo recebido na function.

        Returns:
            _type_: tipo em uppercase.
        '''
        return type.upper()


class CronTab(_CronTab):
    """Classe responsável por facilitar a manipulação de agendamentos."""

    def next(
        self,
        now: DateTime = pendulum.now('UTC'),
        increments: List[Callable] = _increments,
        delta: bool = True,
        default_utc: bool = False,
        return_datetime: bool = True,
    ) -> str:
        """Calcula a data da próxima ocorrência do cron schedule.

        Args:
            now (DateTime, optional):
                data base na qual o cron scheduler será calculado.
                Defaults to pendulum.now('UTC').
            increments (list[Callable], optional):
                indica se o cálculo da data irá ser incremental ou decremental.
                Defaults to _increments.
            delta (bool, optional): _description_.
                Defaults to True.
            default_utc (bool, optional): _description_.
                Defaults to False.
            return_datetime (bool, optional):
                retorno em datetime caso seja True.
                Defaults to True.

        Returns:
            str: string representando o próximo scheduler.
        """
        as_datetime: DateTime = super().next(
            now,
            increments,
            delta,
            default_utc,
            return_datetime,
        )
        return as_datetime.format('YYYY-MM-DD HH:mm:ss')

    def previous(self) -> str:
        """Calcula a data da última ocorrência do cron schedule.

        Returns:
            str: string representando o último scheduler.
        """
        return super().previous(now=pendulum.now('UTC'))

def get_logger() -> Logger:
    """Função que cria e retorna objeto "logger".

    Returns:
        logging.Logger: Objeto logger configurado.
    """
    cloud_logging_client = Client()
    cloud_logging_handler = cloud_logging_client.get_default_handler()

    logger = getLogger('dag-creator-function')
    logger.setLevel(INFO)
    logger.addHandler(cloud_logging_handler)

    return logger

def update_attributes(model: BaseModel, attributes: dict):
    for attr, value in attributes.items():
        setattr(model, attr, value)