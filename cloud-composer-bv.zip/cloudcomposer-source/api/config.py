from environ import config
from environ import var



@config
class Config:
  PROJECT_ID = var(default='oceanic-cache-349523')
  FIRESTORE_DEFAULT_COLLECTION = var(default='TbConfigCarga')
  JSON_NEW_CONTRACT = {
    'ConfigAirflow': {
      'DsCronScheduler': '00 17 * * *', 
      'FlModificado': True, 
      'NmOwner': 'TransAnalytics', 
      'DsEmail': ['jorge.ssilva@bv.com.br'], 
      'DtStartDate': '2022-10-20 17:00:00', 
      'DsTipoCarga': 'INGESTAO'
    }, 
    'ConfigDataflow': {
      'PipelineOptions': {
        'NmTabela': 'dbcart.dbo.tbcontrolearquivo', 
        'NmDatasetDestino': 'work_dbcart_dbo', 
        'NmTabelaDestino': 'tbcontrolearquivo', 
        'FlCargaFull': True, 
        'NmDatabase': 'SQL_SERVER', 
        'DsHost': '127.0.0.1', 
        'NuPorta': 2500, 
        'DsPointerField': 'DtInclusao', 
        'NmProjeto': 'oceanic-cache-349523', 
        'FlParalelismoResult': False, 
        'NmProjetoSecretManager': 'bv-si-si-siem-prd', 
        'DsChaveAcesso': 'arqd-mssql-pwd-transanlt_batch-oceanic-cache-349523', 
        'NmChaveAcesso': 'arqd-mssql-usr-transanlt_batch-oceanic-cache-349523', 
        'DsPrefixoArquivoSaida': 'tbcontrolearquivo', 
        'QtArquivoSaida': 1, 
        'DsDiretorioSaida': 'gs://general-purpose-bucket-dougras/raw/sqlserver/dbcart/dbo/tbcontrolearquivo', 
        'NmProjetoDatalake': 'oceanic-cache-349523'
      }, 
      'Infra': {
        'NmBigQuery': 'general-purpose-bucket-dougras', 
        'DsRegiaoDefault': 'us-east1', 
        'NuDefaultWorkers': 1, 
        'NuMaxWorkers': 1, 
        'DsSubnetwork': 'https://www.googleapis.com/compute/v1/projects/network-bv/regions/us-east1/subnetworks/sub-des', 
        'DsInstancia': 'n1-standard-1', 
        'DsEmail': 'sa-arqd-anlt-batch-des-transan@oceanic-cache-349523.iam.gserviceaccount.com', 
        'DsNetworkTags': 'des;internet;padrao', 
        'DsVersaoDataflowTemplate': '1.1.0', 
        'DsCaminhoFlexTemplate': 'gs://oceanic-cache-349523/dataflow/templates/templatedataflow-arqd-base-motor-ingestao-1.1.0.json', 
        'DsTempLocation': 'gs://oceanic-cache-349523/dataflow/temp/', 
        'DsStageLocation': 'gs://oceanic-cache-349523/dataflow/staging/', 
        'NuTimeoutJobDataflow': 18000, 
        'DsURLJobDataflow': 'https://dataflow.googleapis.com/v1b3/projects/oceanic-cache-349523/locations/us-east1/jobs/', 
        'NuIntervaloPoke': 30
      }
    }, 
    'ConfigApplication': {
      'DsVersaoCloudFunction': '1.2.6', 
      'DsVersaoDagTemplate': '1.2.0'
    }, 
    'ConfigBigQuery': {
      'NmParticaoTrusted': 'DtInclusao', 
      'NmTabelaTrusted': 'oceanic-cache-349523.trusted_dbcart_dbo.tbcontrolearquivo', 
      'NmTabelaWork': 'oceanic-cache-349523.work_dbcart_dbo.tbcontrolearquivo', 
      'Infra': {
        'DsSourceURI': 'gs://general-purpose-bucket-dougras/raw/sqlserver/dbcart/dbo/tbcontrolearquivo/*', 
        'DsSourceURIPrefix': 'gs://general-purpose-bucket-dougras/raw/sqlserver/dbcart/dbo/tbcontrolearquivo/'
      }, 
      'LstChavesTrusted': ['CdControleArquivo'], 
      'NmBigQueryConn': 'bigquery_default', 
      'DsTipoParticao': 'DAY', 
      'LstCamposClusterizacao': []
    }, 
    'ConfigFile': None
  }

  # TODO: excluir, estou usando para testar somente
  JSON_SSH_EXAMPLE = {
    'ConfigDataflow': {
      'ParametrosPipeline': {
        'NmDatabase': '',
        'NuPorta': 1,
        'ConfigConnection': {
          'RemotePath': '/home/douglas/ssh/table.csv',
          'CSVSkipLeadingRows': 1,
          'FileCompressao': True,
          'NmHostname': 'test_us_east1_ssh_zip_people3',
          'CSVDelimiter': ';',
          'FileNmBucketDestino': 'general-purpose-bucket-dougras',
          'FileSchemaFields':[
            { 'name': 'name', 'type': 'STRING' },
            { 'name': 'age',  'type': 'INTEGER' },
            { 'name': 'city', 'type': 'STRING' },
            { 'name': 'date_cad', 'type': 'DATE' }
          ],
          'DsSourceURILanding': 'ssh_output',
          'Nmconexao': 'instance-1-kkkkj'
        },
        'FlCargaFull': True,
        'NmDatasetDestino': 'work_dbcart',
        'NmProjetoSecretManager': 'bv-si-si-siem-prd',
        'DsPointerField': '',
        'NmChaveAcesso': 'xuxuzinho_ssh',
        'DsDiretorioSaida': 'gs://general-purpose-bucket-dougras/raw/output',
        'NmTabelaDestino': 'people3',
        'DsHost': '0.0.0.0',
        'DsPrefixoArquivoSaida': '',
        'DsChaveAcesso': '',
        'QtArquivoSaida': 1,
        'FlParalelismoResult': False,
        'NmProjetoDatalake': 'bv-analytics-bigd-des',
        'NmTabela': 'test_us_east1_ssh_zip_people3.dbcart.people3',
        'DsFiltroExtracao': ''
      },
      'DsStageLocation': 'gs://oceanic-cache-349523/dataflow/staging/',
      'DsCaminhoFlexTemplate': 'gs://oceanic-cache-349523/dataflow/templates/templatedataflow-arqd-base-motor-ingestao-1.1.0.json',
      'DsInstancia': 'n1-standard-1',
      'DsURLJobDataflow': 'https://dataflow.googleapis.com/v1b3/projects/oceanic-cache-349523/locations/us-east1/jobs/',
      'DsNetworkTags': 'des;internet;padrao',
      'NuDefaultWorkers': 1,
      'DsTempLocation': 'gs://general-purpose-bucket-dougras/temp/',
      'NmDataflowJob': 'ingestion-people3-20221013-204130',
      'DsRegiaoDefault': 'us-east1',
      'NmProjeto': 'oceanic-cache-349523',
      'NuIntervaloPoke': 30,
      'DsSubnetwork': 'https://www.googleapis.com/compute/v1/projects/network-bv/regions/us-east1/subnetworks/sub-des',
      'DsEmail': 'sa-arqd-anlt-batch-des-transan@oceanic-cache-349523.iam.gserviceaccount.com',
      'NuMaxWorkers': 1,
      'NuTimeoutJobDataflow': 18000
    },
    'ConfigAirflow': {
      'NmBigQueryConn': 'bigquery_default',
      'DsRegiaoDefault': 'us-east1',
      'DsTipoCarga': 'INGESTAO_SSH',
      'NmParticaoTrusted': 'date_cad',
      'DtStartDate': '2022-10-13 17:00:00',
      'DsVersaoDagTemplate': '1.2.0',
      'NmProjeto': 'oceanic-cache-349523',
      'DsEmail':['rodrigo.goncalves@bv.com.br'],
      'DsVersaoCloudFunction': '1.2.6',
      'NmOwner': 'TransAnalytics',
      'LstCamposClusterizacao':[],
      'DsSourceURIPrefix': 'gs://bv-datalakedes01/raw/ssh/dbcart/people3/',
      'NmTabelaTrusted': 'oceanic-cache-349523.trusted_dbcart.people1',
      'DsCronScheduler': '00 17 * * *',
      'LstChavesTrusted':['name'],
      'NmTabelaWork': 'bv-analytics-bigd-des.work_dbcart.people3',
      'FlModificado': True,
      'DsTipoParticao': 'DAY',
      'DsVersaoDataflowTemplate': '1.1.0',
      'DsSourceURI': 'gs://bv-datalakedes01/raw/ssh/dbcart/people3/*'
    }
  }


  JSON_SFTP_EXAMPLE = {
    'ConfigDataflow':{
      'DsEmail': 'admin-bigquery@oceanic-cache-349523.iam.gserviceaccount.com',
      'NuIntervaloPoke': 30,
      'NuTimeoutJobDataflow': 18000,
      'DsRegiaoDefault': 'us-east1',
      'DsNetworkTags': 'des;internet;padrao',
      'DsURLJobDataflow': 'https://dataflow.googleapis.com/v1b3/projects/oceanic-cache-349523/locations/us-east1/jobs/',
      'NuMaxWorkers': 1,
      'DsStageLocation': 'gs://oceanic-cache-349523/dataflow/staging/',
      'NuDefaultWorkers': 1,
      'DsCaminhoFlexTemplate': 'gs://oceanic-cache-349523/dataflow/templates/templatedataflow-arqd-base-motor-ingestao-1.1.0.json',
      'ParametrosPipeline':{
        'NmProjetoSecretManager': 'bv-si-si-siem-prd',
        'DsChaveAcesso': '',
        'DsPointerField': '',
        'NmChaveAcesso': 'xuxuzinho_sftp',
        'NuPorta': 1,
        'DsFiltroExtracao': '',
        'QtArquivoSaida': 1,
        'NmTabela': 'test_us_east1_sftp_carga_full_people1.dbcart.people1',
        'NmDatabase': '',
        'DsPrefixoArquivoSaida': '',
        'ConfigConnection':{
          'DsSourceURILanding': 'sftp_output',
          'RemotePath': '/sftp/table.csv',
          'CSVSkipLeadingRows': 1,
          'NmHostname': 'test_us_east1_sftp_carga_full_people1',
          'FileCompressao': False,
          'Nmconexao': 'sftp_srv_arqdados04',
          'CSVDelimiter': ';',
          'FileSchemaFields':[
            { 'name': 'name', 'type': 'STRING' },
            { 'type': 'INTEGER', 'name': 'age' },
            { 'name': 'city', 'type': 'STRING' },
            { 'type': 'DATE', 'name': 'date_cad' }
          ],
          'FileNmBucketDestino': 'general-purpose-bucket-dougras'
        },
        'NmDatasetDestino': 'work_dbcart',
        'NmProjetoDatalake': 'oceanic-cache-349523',
        'DsDiretorioSaida': 'gs://general-purpose-bucket-dougras/raw/sftp/dbcart/people1',
        'NmTabelaDestino': 'people1',
        'FlParalelismoResult': False,
        'FlCargaFull': True,
        'DsHost': '0.0.0.0'
      },
      'DsInstancia': 'n1-standard-1',
      'DsTempLocation': 'gs://oceanic-cache-349523/dataflow/temp/',
      'NmProjeto': 'oceanic-cache-349523',
      'NmDataflowJob': 'ingestion-people1-20221010-191153',
      'DsSubnetwork': 'https://www.googleapis.com/compute/v1/projects/network-bv/regions/us-east1/subnetworks/sub-des'
  },
    'ConfigAirflow':{
        'DsRegiaoDefault': 'us-east1',
        'DsTipoCarga': 'INGESTAO_SFTP',
        'DsEmail':['rodrigo.goncalves@bv.com.br'],
        'NmBigQueryConn': 'bigquery_default',
        'NmOwner': 'TransAnalytics',
        'NmProjeto': 'oceanic-cache-349523',
        'LstChavesTrusted':['name'],
        'DsVersaoCloudFunction': '1.2.6',
        'DsVersaoDataflowTemplate': '1.1.0',
        'FlModificado': True,
        'DsSourceURI': 'gs://general-purpose-bucket-dougras/raw/sftp/dbcart/people1/*',
        'LstCamposClusterizacao':[],
        'DsCronScheduler': '00 20 * * *',
        'DsVersaoDagTemplate': '1.2.0',
        'NmParticaoTrusted': 'date_cad',
        'NmTabelaWork': 'oceanic-cache-349523.work_dbcart.people1',
        'DtStartDate': '2022-10-09 20:00:00',
        'NmTabelaTrusted': 'oceanic-cache-349523.trusted_dbcart.people1',
        'DsTipoParticao': 'DAY',
        'DsSourceURIPrefix': 'gs://general-purpose-bucket-dougras/raw/sftp/dbcart/people1/'
    }
  }

  JSON_EXAMPLE = {
    "ConfigDataflow": {
      "NuTimeoutJobDataflow": 18000,
      "NuDefaultWorkers": 1,
      "DsTempLocation": "gs://oceanic-cache-349523/dataflow/temp/",
      "DsStageLocation": "gs://oceanic-cache-349523/dataflow/staging/",
      "DsURLJobDataflow": "https://dataflow.googleapis.com/v1b3/projects/oceanic-cache-349523/locations/us-east1/jobs/",
      "ParametrosPipeline": {
        "NmDatasetDestino": "dbcart_dbo",
        "DsChaveAcesso": "arqd-mssql-pwd-transanlt_batch-oceanic-cache-349523",
        "NmTabelaDestino": "tbcontrolearquivo",
        "NmProjetoDatalake": "oceanic-cache-349523",
        "DsFiltroExtracao": "",
        "NmChaveAcesso": "arqd-mssql-usr-transanlt_batch-oceanic-cache-349523",
        "FlParalelismoResult": False,
        "DsPrefixoArquivoSaida": "tbcontrolearquivo",
        "DsHost": "127.0.0.1",
        "DsPointerField": "DtInclusao",
        "DsDiretorioSaida": "gs://bv-datalakedes01/raw/sqlserver/dbcart/dbo/tbcontrolearquivo",
        "NmTabela": "dbcart.dbo.tbcontrolearquivo",
        "FlCargaFull": True,
        "NmProjetoSecretManager": "secret_manager_project_id",
        "NmDatabase": "SQL_SERVER",
        "NuPorta": 2500,
        "QtArquivoSaida": 1
      },
      "DsCaminhoFlexTemplate": "gs://oceanic-cache-349523/dataflow/templates/templatedataflow-arqd-base-motor-ingestao-1.1.0.json",
      "DsEmail": "sa-arqd-anlt-batch-des-transan@oceanic-cache-349523.iam.gserviceaccount.com",
      "NuMaxWorkers": 1,
      "DsRegiaoDefault": "us-east1",
      "NmDataflowJob": "ingestion-tbcontrolearquivo-20220606-152250",
      "NuIntervaloPoke": 30,
      "DsSubnetwork": "subnetwork",
      "NmProjeto": "oceanic-cache-349523",
      "DsInstancia": "n1-standard-1",
      "DsNetworkTags": "des;internet;padrao"
    },
    "ConfigAirflow": {
      "DsCronScheduler": "00 17 * * *",
      "DsVersaoDagTemplate": "1.2.0",
      "DsVersaoCloudFunction": "1.2.6",
      "FlModificado": True,
      "DsVersaoDataflowTemplate": "1.1.0",
      "DsRegiaoDefault": "us-east1",
      "LstCamposClusterizacao": [],
      "NmParticaoTrusted": "DtInclusao",
      "NmBigQueryConn": "bigquery_default",
      "DtStartDate": "2022-06-05 17:00:00",
      "NmTabelaTrusted": "oceanic-cache-349523.trusted_dbcart_dbo.tbcontrolearquivo",
      "NmOwner": "TransAnalytics",
      "NmTabelaWork": "oceanic-cache-349523.work_dbcart_dbo.tbcontrolearquivo",
      "LstChavesTrusted": ["CdControleArquivo"],
      "DsTipoCarga": "INGESTAO",
      "DsSourceURIPrefix": "gs://general-purpose-bucket-dougras/tbcontrolearquivo/",
      "NmProjeto": "oceanic-cache-349523",
      "DsSourceURI": "gs://general-purpose-bucket-dougras/tbcontrolearquivo/*",
      "DsEmail": [
        "rodrigo.goncalves@bv.com.br"
      ],
      "DsTipoParticao": "DAY"
    }
  }

CONFIG: Config = Config.from_environ() # type: ignore
