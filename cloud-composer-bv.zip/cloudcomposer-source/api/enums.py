from enum import Enum
from enum import auto



class PartitionTypes(str, Enum):
  HOUR = 'HOUR'
  DAY = 'DAY'
  MONTH = 'MONTH'
  YEAR = 'YEAR'


class SchemaFieldTypes(str, Enum):
  STRING = 'STRING'
  BYTES = 'BYTES'
  INTEGER = 'INTEGER'
  FLOAT = 'FLOAT'
  NUMERIC = 'NUMERIC'
  BIGNUMERIC = 'BIGNUMERIC'
  BOOLEAN = 'BOOLEAN'
  TIMESTAMP = 'TIMESTAMP'
  DATE = 'DATE'
  TIME = 'TIME'
  DATETIME = 'DATETIME'
  GEOGRAPHY = 'GEOGRAPHY'
  RECORD = 'RECORD'
  JSON = 'JSON'


class SchemaFieldModes(str, Enum):
  NULLABLE = 'NULLABLE'
  REPEATED = 'REPEATED'


class TriggerRules(str, Enum):
  ALL_SUCCESS = 'all_success'
  ALL_FAILED = 'all_failed'
  ALL_DONE = 'all_done'
  ONE_SUCCESS = 'one_success'
  ONE_FAILED = 'one_failed'
  NONE_FAILED = 'none_failed'
  NONE_FAILED_OR_SKIPPED = 'none_failed_or_skipped'
  NONE_SKIPPED = 'none_skipped'
  DUMMY = 'dummy'
  ALWAYS = 'always'
  NONE_FAILED_MIN_ONE_SUCCESS = "none_failed_min_one_success"
  ALL_SKIPPED = 'all_skipped'


class PublishTaskStates(str, Enum):
  FAIL = 'Fail'
  SUCCESS = 'Success'


class TaskTypes(Enum):
  START = auto()
  RAW_INGESTION = auto()
  RAW_INGESTION_SENSOR = auto()
  EXTERNAL_TABLE = auto()
  EXTERNAL_TABLE_SFTP = auto()
  LOAD_TYPE_BRANCH = auto()
  LOAD_BRANCH_COMPRESS = auto()
  LOAD_TRUSTED_FULL = auto()
  MOVE_FILES_FROM_SFTP_TO_GCS = auto()
  MOVE_FILES_FROM_SSH_TO_GCS = auto()
  SFTP_DATAFLOW_DECOMPRESS_JOB = auto()
  SFTP_MOVE_FILES_TO_RAW = auto()
  LOAD_TRUSTED_INCREMENTAL = auto()
  TRUSTED_LOAD = auto()
  CREATE_TRUSTED_TABLE = auto()
  PUBLISH_SUCCESS_OPERATOR = auto() 
  PUBLISH_FAIL_OPERATOR = auto()
  END = auto()


class DagTypes(Enum):
  BATCH_INGESTION_REPROCESSING_DAG = 'REPROCESSAMENTO'
  BATCH_SFTP_DAG = 'INGESTAO_SFTP'
  BATCH_INGESTION_DAG = 'INGESTAO'
  BATCH_SSH_DAG = 'INGESTAO_SSH'


class SortColumnMethods(str, Enum):
  DESCENDANT = 'desc'
  CRESCENT = 'asc'
  NONE = ''


class ColumnSeparators(str, Enum):
  COMMA = ', '
  AND = ' AND '
