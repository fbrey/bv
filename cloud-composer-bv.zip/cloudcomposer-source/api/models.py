from __future__ import annotations

from datetime import timedelta
from datetime import datetime
from typing import List
from typing import Optional
from abc import ABC
import logging

from pydantic import root_validator
from pydantic import validator
from pydantic import BaseModel
from pydantic import EmailStr
from pandas import DataFrame
from pydantic import Field

from utils import ModelPopulatedByFieldName
from utils import ArbitraryTypeModel
from enums import SchemaFieldModes
from enums import SchemaFieldTypes
from enums import PartitionTypes
from enums import DagTypes
from utils import CustomDictModel



class Airflow(BaseModel):
  cron_scheduler: str = Field(alias='DsCronScheduler')
  updated: bool = Field(alias='FlModificado')
  owner: str = Field(alias='NmOwner')
  email: List[EmailStr] = Field(alias='DsEmail')
  start_date: str = Field(alias='DtStartDate')
  load_type: DagTypes = Field(alias='DsTipoCarga')


class Application(ModelPopulatedByFieldName):
  cloud_function_version: str = Field(alias='DsVersaoCloudFunction')
  dag_template_version: str = Field(alias='DsVersaoDagTemplate')


class BigQueryInfra(ModelPopulatedByFieldName):
	source_uri: str = Field(alias='DsSourceURI')
	source_uri_prefix: str = Field(alias='DsSourceURIPrefix')


class BigQuery(ModelPopulatedByFieldName):
  trusted_partition: str = Field(alias='NmParticaoTrusted')
  trusted_table: str = Field(alias='NmTabelaTrusted')
  work_table: str = Field(alias='NmTabelaWork')
  infra: BigQueryInfra = Field(alias='Infra')
  trusted_keys: List[str] = Field(alias='LstChavesTrusted')
  big_query_conn: str = Field(alias='NmBigQueryConn')
  partition_type: str = Field(alias='DsTipoParticao')
  clustering_fields: List = Field(alias='LstCamposClusterizacao')


  @property
  def project_id(self) -> str:
    return self.trusted_table.split('.')[0]

  @property
  def trusted_dataset_id(self) -> str:
    return self.trusted_table.split('.')[1]

  @property
  def work_dataset_id(self) -> str:
    return self.work_table.split(".")[1]

  @property
  def table_id(self) -> str:
    return self.trusted_table.split('.')[2]

  @validator('trusted_partition', allow_reuse=True)
  def transform_trusted_partition_to_lower(cls, trusted_partition: str) -> str:
    return trusted_partition.strip().lower()

  @validator('trusted_keys', allow_reuse=True)
  def transform_trusted_keys_to_lower(cls, trusted_keys: List[str]) -> str:
    return [key.strip().lower() for key in trusted_keys]


class DataflowInfra(BaseModel):
  region: str = Field(alias='DsRegiaoDefault')
  workers: int = Field(alias='NuDefaultWorkers')
  max_workers: int = Field(alias='NuMaxWorkers')
  subnetwork: str = Field(alias='DsSubnetwork')
  instance: str = Field(alias='DsInstancia')
  email: EmailStr = Field(alias='DsEmail')
  network_tags: str = Field(alias='DsNetworkTags')
  template_version: str = Field(alias='DsVersaoDataflowTemplate')
  path_flex_template: str = Field(alias='DsCaminhoFlexTemplate')
  temporary_location: str = Field(alias='DsTempLocation')
  stage_location: str = Field(alias='DsStageLocation')
  timeout_job: int = Field(alias='NuTimeoutJobDataflow')
  url_job: str = Field(alias='DsURLJobDataflow')
  poke_interval: int = Field(alias='NuIntervaloPoke')

  @property
  def zone_region(self) -> str:
    return f'{self.region}-b' # TODO: trocar para {self.region}-a


class PipelineOptions(CustomDictModel):
  table_name: str = Field(alias='NmTabela')
  target_dataset_name: str = Field(alias='NmDatasetDestino')
  target_table_name: str = Field(alias='NmTabelaDestino')
  full_load: bool = Field(alias='FlCargaFull')
  database_name: str = Field(alias='NmDatabase')
  host: str = Field(alias='DsHost')
  port: int = Field(alias='NuPorta')
  pointer_field: str = Field(alias='DsPointerField')
  project_name: str = Field(alias='NmProjeto')
  parallel: bool = Field(alias='FlParalelismoResult')
  secret_manager_id: str = Field(alias='NmProjetoSecretManager')
  access_key_password: str = Field(alias='DsChaveAcesso')
  access_key_name: str = Field(alias='NmChaveAcesso')
  prefix_output_file: str = Field(alias='DsPrefixoArquivoSaida')
  quantity_output_files: int = Field(alias='QtArquivoSaida')
  output_directory: str = Field(alias='DsDiretorioSaida')
  datalake_project: str = Field(alias='NmProjetoDatalake')
  extraction_filter: Optional[str] = Field(alias='DsFiltroExtracao')

  @property
  def bucket_datalake_instance(self) -> str:
    return self.output_directory.split('/')[2]
  
  @property
  def bucket_datalake_path(self) -> str:
    return self.output_directory[self.output_directory.index('raw'):]
  
  @property
  def destination_object(self) -> str:
    return f'{self.bucket_datalake_path}/DT_INGESTION={{{{ds}}}}/'
  
  @property
  def output_directories(self) -> str:
    return f'{self.output_directory}/*'
  
  @property
  def file_processing_branch(self) -> str:
    if self.connection.file_compression:
      return 'file_processing.dataflow_decompress_job'
    return 'file_processing.mov_files_to_raw'
  
  @property
  def transformation_branch(self) -> str:
    if self.full_load:
      return 'transform_trusted_data.trusted_full'
    return 'transform_trusted_data.trusted_incremental'
  
  @property
  def table_name_with_minus_signal(self) -> str:
    return self.table_name.lower().replace('_', '').replace('.', '-')


class Dataflow(ModelPopulatedByFieldName):
  pipeline: PipelineOptions = Field(alias='PipelineOptions')
  infra: DataflowInfra = Field(alias='Infra')


class File(BaseModel):
  connection_name: str = Field(alias='Nmconexao')
  remote_path: str = Field(alias='RemotePath')
  file_bucket_destination: str = Field(alias='FileNmBucketDestino')
  file_compression: bool = Field(alias='FileCompressao', default=False)
  file_schema_fields: List[SchemaField] = Field(alias='FileSchemaFields', default=[])
  field_delimiter: str = Field(alias='CSVDelimiter', default=';')
  file_skip_leading_rows: int = Field(alias='CSVSkipLeadingRows', default=0)
  source_uri: str = Field(alias='DsSourceURILanding')
  hostname: str = Field(alias='NmHostname')

  @property
  def output_fail_file(self) -> str:
    return f'gs://{self.file_bucket_destination}/temp/erro.txt'
  
  @property
  def autodetect(self) -> bool:
    return len(self.file_schema_fields) == 0
  
  @property
  def schema_as_dict(self) -> dict:
    if len(self.file_schema_fields) > 0:
      return {
        'fields': [schema.dict() for schema in self.file_schema_fields]
      }
  
  @property
  def remote_file(self) -> str:
    return self.remote_path.split('/')[-1]
  
  @property
  def destination_path(self) -> str:
    return f'{self.source_uri}/DT_INGESTION={{{{ds}}}}/{self.remote_file}'
  
  @property
  def source_object(self) -> str:
    return f'{self.destination_path}/*'


class Contract(ModelPopulatedByFieldName):
  airflow: Airflow = Field(alias='ConfigAirflow')
  dataflow: Dataflow = Field(alias='ConfigDataflow')
  application: Application = Field(alias='ConfigApplication')
  big_query: BigQuery = Field(alias='ConfigBigQuery')
  file: Optional[File] = Field(alias='ConfigFile')


class DagArguments(CustomDictModel):
  table_name: str = Field(hidden=True)
  default_args: DagDefaultArguments
  schedule_interval: str
  tags: List[str]

  dag_id: Optional[str]
  catchup: bool = False
  description: str = 'DAG gerada automaticamente pela plataforma Chameleon'
  max_active_runs: int = 1

  @root_validator(allow_reuse=True)
  def create_dag_id(cls, values: dict):
    table_name: str = values['table_name']
    underscored_table_name = table_name.replace('.', '_').lower() # TODO: colocar esse lower na function
    dag_id = f'ing_{underscored_table_name}'

    max_length = 65
    if len(dag_id) >= max_length:
      truncated_dag_id = dag_id[:max_length - 1]
      logging.info(f'DAG_ID cannot exceed max length of {max_length} ')
      logging.info(f'Truncating DAG_ID from {dag_id} to {truncated_dag_id}')
      values['dag_id'] = truncated_dag_id
    
    values['dag_id'] = dag_id
    return values


class DagDefaultArguments(BaseModel):
  email: List[EmailStr]
  start_date: datetime

  owner: str = 'Plataforma Chameleon'
  depends_on_past: bool = False
  email_on_failure: bool = False
  email_on_retry: bool = False
  retries: int = 0
  execution_timeout: timedelta = timedelta(minutes=10)
  catchup: bool = False


class InformationSchema(ArbitraryTypeModel):
  raw_schema: DataFrame

  def validate_trusted_keys(self, contract: Contract):
    trusted_keys = contract.big_query.trusted_keys
    valid_trusted_keys = all(value in self.names for value in trusted_keys)

    if valid_trusted_keys and len(trusted_keys):
      logging.info(f"Keys are valid: {trusted_keys}")
    elif not len(trusted_keys):
      logging.info("Empty keys, skipping validation")
    else:
      raise Exception("Please check your parameter trustedKeys, there's some column(s) not found in the table")

  def validate_partition_keys(self, contract: Contract):
    partition_keys = contract.big_query.trusted_partition

    if partition_keys in self.partition_column_names:
      logging.info(f"Partition OK: {partition_keys}")
    elif not partition_keys:
      logging.info("Empty partition, skipping validation")
    else:
      raise Exception("Please check your parameter trustedPartition, you might have a misfound column or its not considered as a partition field in your table")

  @property
  def names(self) -> List[str]:
    return [
      value.strip().lower() 
      for value 
      in self.raw_schema['column_name'].to_list()
    ]

  @property
  def names_without_chameleon_keys(self) -> List[str]:
    names = self.names
    if 'dtcriacaochameleon' in names and 'dtalteracaochameleon' in names:
      names.remove('dtcriacaochameleon')
      names.remove('dtalteracaochameleon')
    return names

  @property
  def names_with_comma(self) -> str:
    return ', '.join(self.names)
  
  @property
  def names_to_select(self) -> str:
    query = self.names_with_comma.replace('dtcriacaochameleon', 'DATETIME(CURRENT_TIMESTAMP(), "America/Sao_Paulo") AS dtcriacaochameleon')
    query = query.replace('dtalteracaochameleon', 'DATETIME(CURRENT_TIMESTAMP(), "America/Sao_Paulo") AS dtalteracaochameleon')
    return query
  
  @property
  def partition_column_names(self) -> List[str]:
    names = self.raw_schema.query('is_partitioning_column == "YES"')['column_name'].to_list()
    return names


class SchemaField(BaseModel):
  name: str
  type: SchemaFieldTypes
  mode: SchemaFieldModes
