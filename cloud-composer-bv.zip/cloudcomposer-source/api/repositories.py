from abc import abstractmethod
from typing import List
from abc import ABC
import logging

from google.cloud.firestore_v1.collection import CollectionReference
from airflow.providers.google.cloud.hooks.bigquery import BigQueryHook
from google.cloud.firestore import Client
from pandas import DataFrame

from enums import PartitionTypes
from models import Contract, SchemaField



class ContractBaseRepository(ABC):
  @abstractmethod
  def get(self, id: str, location: str) -> Contract: 
    raise NotImplementedError()

  @abstractmethod
  def list(self, location: str) -> List[Contract]: 
    raise NotImplementedError()


class Firestore(ContractBaseRepository):
  def __init__(self, project_id: str):
    self.client = Client(project=project_id)
  
  def get(self, document: str, collection='TbConfigCarga') -> Contract:
    collection: CollectionReference = self.client.collection(collection)
    raw_document = collection.document(document_id=document).get().to_dict()
    return Contract(**raw_document)

  def list(self, collection='TbConfigCarga') -> List[Contract]:
    collection = self.client.collection(collection).stream() # TODO: talvez seja necessario usar dict
    return [Contract(**doc.to_dict()) for doc in collection]


class BigQuery:
  def __init__(self, contract: Contract):
    self.airflow = contract.airflow
    self.big_query = contract.big_query
    self.client = BigQueryHook(
      use_legacy_sql=False,
      location=contract.dataflow.infra.region
    )
    self.schema: List[SchemaField] = None
  
  def acquire_schema(self):
    self.schema = self.client.get_schema(
      project_id=self.big_query.project_id,
      dataset_id=self.big_query.work_dataset_id,
      table_id=self.big_query.table_id,
    )['fields']

  def run_query(self, sql: str) -> DataFrame:
    logging.info(f'Rodando a query: {sql}')
    return self.client.get_pandas_df(sql=sql)

  def create_table(self, partition_type: PartitionTypes):
    self.client.create_empty_table(
      project_id=self.big_query.project_id,
      dataset_id=self.big_query.trusted_dataset_id,
      table_id=self.big_query.table_id,
      schema_fields=self.schema,
      exists_ok=False,
      time_partitioning={'field': self.big_query.trusted_partition, 'type': partition_type},
      cluster_fields=self.big_query.clustering_fields
    )

  def update_schema(self):
    self.client.update_table_schema(
      project_id=self.big_query.project_id,
      dataset_id=self.big_query.trusted_dataset_id,
      table_id=self.big_query.table_id,
      schema_fields_updates=self.schema,
      include_policy_tags=True
    )

  def get_field_from_schema(self, key: str) -> dict:
    try:
      return [
        field 
        for field 
        in self.schema 
        if field['name'].lower() == key.lower()
      ].pop()
    except IndexError as e:
      raise RuntimeError(f'Required partition value [{key}] doesn\'t exists in schema.') from e

  def remove_fields_from_schema(self, *keys: str):
    for index, (field, key) in enumerate(zip(self.schema, keys)):
      if field['name'].lower() == key:
        self.schema.pop(index)

  def add_fields_to_schema(self, *fields: SchemaField):
    for field in fields:
      self.schema.append(field.dict())

  @property
  def table_exists(self) -> bool:
    return self.client.table_exists(
      project_id=self.big_query.project_id,
      dataset_id=self.big_query.trusted_dataset_id,
      table_id=self.big_query.table_id,
    )
