from dags import IngestionDag
# from models import Contract
from config import CONFIG
from models import Contract
# from dags import IngestionSSHDag



def main():
  raw = CONFIG.JSON_NEW_CONTRACT
  contract = Contract(**raw)
  ingestion = IngestionDag(contract)
  return ingestion.dag

main()
