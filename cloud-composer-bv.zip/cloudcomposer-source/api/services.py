from typing import List

from pandas import DataFrame

from models import InformationSchema
from models import Contract
from enums import SortColumnMethods
from enums import ColumnSeparators

from utils import log_return



class QueryBuilder:
  def __init__(self, contract: Contract):
    self.big_query = contract.big_query
    self.airflow = contract.airflow
    self.contract = contract

  @property
  @log_return
  def select_information_schema(self) -> DataFrame:
    return f'''
      SELECT column_name, is_partitioning_column 
      FROM `{self.big_query.project_id}.{self.big_query.trusted_dataset_id}.INFORMATION_SCHEMA.COLUMNS` 
      WHERE table_name = '{self.big_query.table_id}'
    '''

  @property
  @log_return
  def create_external_table(self):
    return f'''
      CREATE OR REPLACE EXTERNAL TABLE {self.big_query.work_table}
      WITH PARTITION COLUMNS OPTIONS (
        format = "AVRO",
        uris = [ "{self.big_query.infra.source_uri}" ],
        hive_partition_uri_prefix = "{self.big_query.infra.source_uri_prefix}",
        enable_logical_types = TRUE
      )
    '''

  @log_return
  def get_truncate_trusted_table(self, raw_information_schema: DataFrame):
    information_schema = InformationSchema(raw_schema=raw_information_schema)
    return f'''
      TRUNCATE TABLE `{self.big_query.trusted_table}`; 
      INSERT INTO `{self.big_query.trusted_table}` ( {information_schema.names_with_comma} )
      SELECT {information_schema.names_to_select}
      FROM `{self.big_query.work_table}` AS WRAW 
      WHERE DT_INGESTION = (SELECT MAX(DT_INGESTION) FROM `{self.big_query.work_table}`) 
    '''

  @log_return
  def get_merge_trusted_incremental_table(self, raw_information_schema: DataFrame):
    information_schema = InformationSchema(raw_schema=raw_information_schema)

    information_schema.validate_trusted_keys(self.contract)
    information_schema.validate_partition_keys(self.contract)

    column_name_with_comma = self.add_comma_cols(information_schema.names)
    column_name_insert_datetimes = self.add_comma_cols(information_schema.names_without_chameleon_keys + 2 * ['DATETIME(CURRENT_TIMESTAMP(), "America/Sao_Paulo")'])
    wraw_column_name_with_comma = self.add_comma_cols(information_schema.names_without_chameleon_keys, alias='WRAW')
    column_keys_groupby_with_comma = self.add_comma_cols(self.big_query.trusted_keys)
    merged_keys_partition = list(set(self.big_query.trusted_keys))
    column_keys_orderby_with_comma = self.add_comma_cols(merged_keys_partition, sort_method=SortColumnMethods.DESCENDANT)
    column_update = self.add_equal_cols(information_schema.names_without_chameleon_keys, 'TRUSTED', 'RAW', self.big_query.trusted_partition)
    column_update += ', TRUSTED.dtalteracaochameleon = DATETIME(CURRENT_TIMESTAMP(), "America/Sao_Paulo")'
    column_join_keys_merge = self.add_equal_cols(self.big_query.trusted_keys, 'TRUSTED', 'RAW', self.big_query.trusted_partition, ColumnSeparators.AND)

    return f'''
      MERGE INTO `{self.big_query.trusted_table}` TRUSTED 
      USING ( 
        SELECT {wraw_column_name_with_comma}
        FROM ( 
          SELECT ARRAY_AGG(deduplicated ORDER BY {column_keys_orderby_with_comma} LIMIT 1)[OFFSET(0)] WRAW 
          FROM `{self.big_query.work_table}` AS deduplicated 
          WHERE DT_INGESTION = (SELECT MAX(DT_INGESTION) FROM `{self.big_query.work_table}`) 
          GROUP BY {column_keys_groupby_with_comma}
        ) 
      ) RAW 
      ON ({column_join_keys_merge})
      WHEN NOT MATCHED THEN INSERT ({column_name_with_comma}) VALUES ({column_name_insert_datetimes})
      WHEN MATCHED THEN UPDATE SET {column_update} 
    '''

  def add_comma_cols(self, column_names: List[str], alias='', sort_method=SortColumnMethods.NONE):
    if alias:
      column_names = [f'{alias}.{value}' for value in column_names]

    if sort_method != SortColumnMethods.NONE:
      column_names = [ f'{value} {sort_method}' for value in column_names]

    comma_cols = ', '.join(column_names)

    return comma_cols

  def add_equal_cols(self, list_columns, left_alias='a', right_alias='b', partition='', separator=ColumnSeparators.COMMA):
    column_equals = []

    if partition == 'and' and separator == ColumnSeparators.AND:
      column_equals.append(f'({right_alias}.{partition} IS NULL OR {left_alias}.{partition} = {right_alias}.{partition})')

    column_equals = column_equals + [f'{left_alias}.{value} = {right_alias}.{value}' for value in list_columns]

    return separator.join(column_equals)
