from datetime import timedelta
import json

from airflow.providers.google.cloud.operators.pubsub import PubSubPublishMessageOperator

from tasks.abstractions import UncallableTask
from enums import PublishTaskStates
from enums import TriggerRules
from models import Contract



class PubSubPublishSuccess(UncallableTask):
  def __init__(self,  contract: Contract):
    self.pipeline = contract.dataflow.pipeline
    self.big_query = contract.big_query

  @property
  def operator(self):
    message = {
      'data': json.dumps({
        'nmTrustedTable': f'{self.big_query.trusted_dataset_id}.{self.big_query.table_id}',
        'stTrustedProcessed': PublishTaskStates.FAIL
      }).encode()
    }

    return PubSubPublishMessageOperator(
      task_id='publish_success_task',
      project_id=self.pipeline.project_name,
      topic="{{ var.value.get('pubsub_topic_key') }}",
      messages=[message],
      trigger_rule=TriggerRules.ALL_SUCCESS,
      retry_delay=timedelta(minutes=2),
      retries=1,
    )
