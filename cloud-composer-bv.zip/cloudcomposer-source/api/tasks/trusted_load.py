from datetime import timedelta

from airflow.operators.python import PythonOperator
from airflow.models import TaskInstance

from tasks.abstractions import CallableTask
from enums import TriggerRules
from models import Contract
from repositories import BigQuery



class TrustedLoad(CallableTask):
  def __init__(self, contract: Contract):
    self.big_query = BigQuery(contract)

  @property
  def operator(self) -> PythonOperator:
    return PythonOperator(
      task_id='trusted_execute',
      trigger_rule=TriggerRules.ONE_SUCCESS,
      execution_timeout=timedelta(hours=4),
      retry_delay=timedelta(minutes=2),
      python_callable=self.callable,
      provide_context=True,
      retries=1,
    )

  def callable(self, ti: TaskInstance):
    xcom_pull_tuple = ti.xcom_pull(
      task_ids=[
        'transform_trusted_data.trusted_full', 
        'transform_trusted_data.trusted_incremental'
      ], 
      key='sql_trusted'
    )

    sql = [
      query
      for query 
      in xcom_pull_tuple 
      if query
    ].pop()
    self.big_query.run_query(sql)
