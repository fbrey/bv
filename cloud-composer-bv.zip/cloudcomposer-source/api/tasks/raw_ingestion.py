from datetime import timedelta

from airflow.providers.google.cloud.operators.dataflow import DataflowStartFlexTemplateOperator

from tasks.abstractions import UncallableTask
from models import Contract



class RawIngestion(UncallableTask):
  def __init__(self, contract: Contract):
    self.pipeline = contract.dataflow.pipeline
    self.infra = contract.dataflow.infra

  @property
  def operator(self):
    return DataflowStartFlexTemplateOperator(
      task_id='call_ingestion_runner',
      execution_timeout=timedelta(hours=24),
      pool=self.pipeline.host,
      retries=2,
      retry_delay=timedelta(minutes=5),
      body={
        'launchParameter': {
          'jobName': f'ing-{self.pipeline.table_name_with_minus_signal}-{{{{macros.ds_format(ts_nodash, "%Y%m%dT%H%M%S", 'f'"%Y%m%d%H%M")}}}}',
          'containerSpecGcsPath': "{{ var.value.get('dataflow_template_spec_path') }}",
          'environment': {
            'subnetwork': self.infra.subnetwork,
            'numWorkers': self.infra.workers,
            'maxWorkers': self.infra.max_workers,
            'machineType': self.infra.instance,
            'serviceAccountEmail': self.infra.email,
            'tempLocation': self.infra.temporary_location,
            'ipConfiguration': 'WORKER_IP_PRIVATE'
          },
          'parameters': {
            f'{key[0].lower()}{key[1:]}': value
            for key, value
            in self.pipeline.dict(by_alias=True).items()
          }
        }
      },
      location=self.infra.region,
      wait_until_finished=True
    )
