from datetime import timedelta

from airflow.providers.google.cloud.transfers.gcs_to_gcs import GCSToGCSOperator

from tasks.abstractions import UncallableTask
from models import Contract



class MoveFilesToRaw(UncallableTask):
  def __init__(self, contract: Contract):
    self.file = contract.file
    self.pipeline = contract.dataflow.pipeline

  @property
  def operator(self) -> GCSToGCSOperator:
    return GCSToGCSOperator(
      task_id='mov_files_to_raw',
      retries=2,
      retry_delay=timedelta(minutes=3),
      source_bucket=self.file.file_bucket_destination,
      source_object=self.file.source_object,
      destination_bucket=self.pipeline.bucket_datalake_path,
      destination_object=self.pipeline.destination_object 
    )
