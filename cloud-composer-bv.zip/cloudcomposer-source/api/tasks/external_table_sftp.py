from datetime import timedelta

from airflow.providers.google.cloud.operators.bigquery import BigQueryCreateExternalTableOperator
from airflow.utils.trigger_rule import TriggerRule

from tasks.abstractions import UncallableTask
from models import Contract



class ExternalTableSftp(UncallableTask):
  def __init__(self, contract: Contract):
    self.pipeline = contract.dataflow.pipeline
    self.file = contract.file

  @property
  def operator(self):
    return BigQueryCreateExternalTableOperator(
      task_id = 'create_external_table_sftp',
      retries=2,
      retry_delay=timedelta(minutes=3),
      trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS,
      bucket=self.pipeline.bucket_datalake_instance,
      table_resource={
        'tableReference': {
          'projectId': self.pipeline.datalake_project,
          'datasetId': self.pipeline.target_dataset_name,
          'tableId': self.pipeline.target_table_name,
        },
        'schema': self.file.schema_as_dict,
        'externalDataConfiguration': {
          'autodetect': self.file.autodetect, 
          'sourceUris': self.pipeline.output_directories,
          'sourceFormat': 'CSV',
          'csvOptions': {
            'allowJaggedRows': False,
            'allowQuotedNewlines': False,
            'encoding': 'UTF-8',
            'fieldDelimiter': self.file.field_delimiter,
            'quote': '\'',
            'skipLeadingRows': self.file.file_skip_leading_rows,
          },
          'hivePartitioningOptions': {
            'mode': 'AUTO',
            'sourceUriPrefix': self.pipeline.output_directory,
          },
        }
      }
    )
