from datetime import timedelta

from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator

from tasks.abstractions import UncallableTask
from models import Contract
from services import QueryBuilder



class ExternalTable(UncallableTask):
  def __init__(self, contract: Contract):
    self.builder = QueryBuilder(contract)
    self.big_query = contract.big_query
    self.dataflow = contract.dataflow

  @property
  def operator(self):
    return BigQueryInsertJobOperator(
      task_id='create_external_table',
      retry_delay=timedelta(minutes=2),
      retries=1,
      configuration={
        'gcp_conn_id': self.big_query.big_query_conn,
        'location': self.dataflow.infra.region,
        'query': {
          'query': self.builder.create_external_table,
          'useLegacySql': False
        },
      }
    )
