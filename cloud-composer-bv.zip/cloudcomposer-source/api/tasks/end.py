from airflow.utils.trigger_rule import TriggerRule
from airflow.operators.dummy import DummyOperator

from tasks.abstractions import UncallableTask
from models import Contract



class End(UncallableTask):
  def __init__(self, contract: Contract):
    ...

  @property
  def operator(self):
    return DummyOperator(task_id='end_dag', trigger_rule=TriggerRule.NONE_FAILED_MIN_ONE_SUCCESS)
