from datetime import timedelta

from airflow.operators.python import PythonOperator
from airflow.models import TaskInstance

from tasks.abstractions import CallableTask
from models import Contract
from repositories import BigQuery
from services import QueryBuilder


class TrustedFull(CallableTask):
  def __init__(self, contract: Contract):
    self.big_query = BigQuery(contract)
    self.query_builder = QueryBuilder(contract)

  @property
  def operator(self) -> PythonOperator:
    return PythonOperator(
      task_id='trusted_full',
      retry_delay=timedelta(minutes=2),
      python_callable=self.callable,
      provide_context=True,
      retries=1,
    )

  def callable(self, ti: TaskInstance):
    information_schema = self.big_query.run_query(self.query_builder.select_information_schema)
    sql_truncate_trusted_table = self.query_builder.get_truncate_trusted_table(information_schema)
    ti.xcom_push(key='sql_trusted', value=sql_truncate_trusted_table)
