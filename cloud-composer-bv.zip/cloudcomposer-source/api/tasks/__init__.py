from pypattyrn.creational.factory import Factory
from airflow.models import BaseOperator

from tasks.create_or_update_trusted_table import CreateOrUpdateTrustedTable
from tasks.dataflow_decompress_job import DataflowDecompressJob
from tasks.end import End
from tasks.external_table_sftp import ExternalTableSftp
from tasks.external_table import ExternalTable
from tasks.load_branch_compress import LoadBranchCompress
from tasks.load_type_branch import LoadTypeBranch
from tasks.move_files_from_sftp_to_gcs import MoveFilesFromSftpToGcs
from tasks.move_files_from_ssh_to_gcs import MoveFilesFromSshToGcs
from tasks.move_files_to_raw import MoveFilesToRaw
from tasks.pubsub_publish_fail import PubSubPublishFail
from tasks.pubsub_publish_success import PubSubPublishSuccess
from tasks.raw_ingestion import RawIngestion
from tasks.start import Start
from tasks.abstractions import UncallableTask
from tasks.trusted_full import TrustedFull
from tasks.trusted_incremental import TrustedIncremental
from tasks.trusted_load import TrustedLoad

from enums import TaskTypes
from models import Contract


class TaskFactory(Factory):
  def __init__(self, contract: Contract):
    self.contract = contract


  def create(self, task_type: TaskTypes) -> BaseOperator:
    tasks = {
      TaskTypes.START: Start,
      TaskTypes.RAW_INGESTION: RawIngestion,
      # TaskTypes.RAW_INGESTION_SENSOR: None,
      TaskTypes.EXTERNAL_TABLE: ExternalTable,
      TaskTypes.EXTERNAL_TABLE_SFTP: ExternalTableSftp,
      TaskTypes.LOAD_TYPE_BRANCH: LoadTypeBranch,
      TaskTypes.LOAD_BRANCH_COMPRESS: LoadBranchCompress,
      TaskTypes.LOAD_TRUSTED_FULL: TrustedFull,
      TaskTypes.MOVE_FILES_FROM_SFTP_TO_GCS: MoveFilesFromSftpToGcs,
      TaskTypes.MOVE_FILES_FROM_SSH_TO_GCS: MoveFilesFromSshToGcs,
      TaskTypes.SFTP_DATAFLOW_DECOMPRESS_JOB: DataflowDecompressJob,
      TaskTypes.SFTP_MOVE_FILES_TO_RAW: MoveFilesToRaw,
      TaskTypes.LOAD_TRUSTED_INCREMENTAL: TrustedIncremental,
      TaskTypes.TRUSTED_LOAD: TrustedLoad,
      TaskTypes.CREATE_TRUSTED_TABLE: CreateOrUpdateTrustedTable,
      TaskTypes.PUBLISH_SUCCESS_OPERATOR : PubSubPublishSuccess,
      TaskTypes.PUBLISH_FAIL_OPERATOR: PubSubPublishFail,
      TaskTypes.END: End,
    }
    task_constructor = tasks[task_type]
    task: UncallableTask = task_constructor(self.contract)
    return task.operator
