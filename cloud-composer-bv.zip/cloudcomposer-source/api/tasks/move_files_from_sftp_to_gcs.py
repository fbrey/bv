from datetime import timedelta

from airflow.providers.google.cloud.transfers.sftp_to_gcs import SFTPToGCSOperator

from tasks.abstractions import UncallableTask
from models import Contract



class MoveFilesFromSftpToGcs(UncallableTask):
  def __init__(self, contract: Contract):
    self.pipeline = contract.dataflow.pipeline
    self.file = contract.file

  @property
  def operator(self) -> SFTPToGCSOperator:
    return SFTPToGCSOperator(
      task_id='move_files_from_sftp_to_gcs',
      destination_bucket=self.file.file_bucket_destination,
      destination_path=self.file.source_uri,
      sftp_conn_id=self.pipeline.access_key_name,
      source_path=self.file.remote_path,
      execution_timeout=timedelta(minutes=60),
      retry_delay=timedelta(minutes=5),
      move_object=False,
      retries=3,
    )
