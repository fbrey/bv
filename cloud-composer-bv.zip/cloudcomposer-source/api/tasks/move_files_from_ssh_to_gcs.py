from datetime import timedelta

from airflow.providers.google.cloud.hooks.compute_ssh import ComputeEngineSSHHook
from airflow.contrib.operators.ssh_operator import SSHOperator

from tasks.abstractions import CommandTask
from models import Contract



class MoveFilesFromSshToGcs(CommandTask):
  def __init__(self, contract: Contract):
    self.file = contract.file
    self.pipeline = contract.dataflow.pipeline
    self.big_query = contract.big_query
    self.dataflow = contract.dataflow

  @property
  def command(self) -> str:
    return f'gsutil cp {self.file.remote_path} gs://{self.file.file_bucket_destination}/{self.file.source_uri}' # TODO ideial seria criar uma property para essa concatenção de atributos, porém n sei um nome representativo o suficiente para isso

  @property
  def operator(self):
    return SSHOperator(
      task_id='move_files_from_fileserver_to_gcs',
      retries=3,
      retry_delay=timedelta(minutes=5),
      execution_timeout = timedelta(minutes=60),
      ssh_hook=ComputeEngineSSHHook(
        project_id=self.big_query.project_id,
        instance_name=self.file.connection_name,
        zone=self.dataflow.infra.zone_region,
        use_oslogin=False,
        use_iap_tunnel=False,
        use_internal_ip=False, # TODO: passar o use_internal_ip para True
        gcp_conn_id=self.pipeline.access_key_name,
      ),
      command=self.command
    )
