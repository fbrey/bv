from abc import abstractmethod
from abc import ABC

from airflow.models import BaseOperator 



class UncallableTask(ABC):
  @property
  @abstractmethod
  def operator(self) -> BaseOperator:
    raise NotImplementedError()


class CallableTask(UncallableTask):
  @abstractmethod
  def callable(self, *args, **kwargs): 
    raise NotImplementedError()


class CommandTask(UncallableTask):
  @property
  @abstractmethod
  def command(self) -> str:
    raise NotImplementedError()