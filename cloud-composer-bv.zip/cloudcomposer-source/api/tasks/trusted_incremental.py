from airflow.operators.python import PythonOperator
from airflow.models import TaskInstance
from datetime import timedelta

from tasks.abstractions import CallableTask
from services import QueryBuilder
from repositories import BigQuery
from models import Contract



class TrustedIncremental(CallableTask):
  def __init__(self, contract: Contract):
    self.query_builder = QueryBuilder(contract)
    self.big_query = BigQuery(contract)

  @property
  def operator(self):
    return PythonOperator(
      task_id='trusted_incremental',
      python_callable=self.callable,
      retry_delay=timedelta(minutes=2),
      provide_context=True,
      retries=1,
    )

  def callable(self, ti: TaskInstance):
    raw_information_schema = self.big_query.run_query(self.query_builder.select_information_schema)
    merge_trusted_incremental_table = self.query_builder.get_merge_trusted_incremental_table(raw_information_schema)
    ti.xcom_push(key='sql_trusted', value=merge_trusted_incremental_table)
