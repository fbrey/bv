from datetime import timedelta

from airflow.providers.google.cloud.operators.dataflow import DataflowTemplatedJobStartOperator

from tasks.abstractions import UncallableTask
from models import Contract



class DataflowDecompressJob(UncallableTask):
  def __init__(self, contract: Contract):
    self.file = contract.file
    self.dataflow = contract.dataflow

  @property
  def operator(self) -> DataflowTemplatedJobStartOperator:
    return DataflowTemplatedJobStartOperator(
      task_id='dataflow_decompress_job',
      template='gs://dataflow-templates/latest/Bulk_Decompress_GCS_Files',
      job_name='ing-sftp-arquivocrm-dataflow-decompress',
      execution_timeout = timedelta(minutes=60),
      retry_delay=timedelta(minutes=3),
      retries=2,
      location=self.dataflow.infra.region,
      parameters={
        'inputFilePattern': f'gs://{self.file.file_bucket_destination}/{self.file.source_uri}/DT_INGESTION={{{{ds}}}}/*',
        'outputDirectory': f'{self.dataflow.pipeline.output_directory}/DT_INGESTION={{{{ds}}}}',
        'outputFailureFile': self.file.output_fail_file
      },
      environment={
        'subnetwork': self.dataflow.infra.subnetwork,
        'numWorkers': self.dataflow.infra.workers,
        'maxWorkers': self.dataflow.infra.max_workers,
        'machineType': self.dataflow.infra.instance,
        'serviceAccountEmail': self.dataflow.infra.email,
        'tempLocation': self.dataflow.infra.temporary_location,
        'ipConfiguration': 'WORKER_IP_PRIVATE'
      },
  )
