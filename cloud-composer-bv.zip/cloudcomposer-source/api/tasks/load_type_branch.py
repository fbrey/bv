from airflow.operators.python import BranchPythonOperator

from tasks.abstractions import CallableTask
from models import Contract



class LoadTypeBranch(CallableTask):
  def __init__(self, contract: Contract):
    self.pipeline = contract.dataflow.pipeline

  def callable(self):
    return self.pipeline.transformation_branch

  @property
  def operator(self):
    return BranchPythonOperator(
      task_id='branch_trusted_load',
      python_callable=self.callable,
      do_xcom_push=False,
    )
