from datetime import timedelta

from airflow.operators.python import PythonOperator
from airflow.models import BaseOperator

from tasks.abstractions import CallableTask
from models import Contract
from models import SchemaField
from enums import SchemaFieldModes
from enums import SchemaFieldTypes
from repositories import BigQuery



class CreateOrUpdateTrustedTable(CallableTask):
  def __init__(self, contract: Contract):
    self.big_query_repository = BigQuery(contract)
    self.big_query = contract.big_query

  def callable(self):
    self.big_query_repository.acquire_schema()
    self.big_query_repository.remove_fields_from_schema('dt_ingestion')
    self.big_query_repository.add_fields_to_schema(
      SchemaField(
        name='dtcriacaochameleon',
        type=SchemaFieldTypes.DATETIME,
        mode=SchemaFieldModes.NULLABLE
      ),
      SchemaField(
        name='dtalteracaochameleon',
        type=SchemaFieldTypes.DATETIME,
        mode=SchemaFieldModes.NULLABLE
      )
    )

    if self.big_query_repository.table_exists:
      self.big_query_repository.update_schema()
    else:
      self.big_query_repository.create_table(self.big_query.partition_type)

  @property
  def operator(self) -> BaseOperator:
    return PythonOperator(
      task_id='create_or_update_trusted_table',
      retries=1,
      retry_delay=timedelta(minutes=2),
      execution_timeout=timedelta(hours=3),
      python_callable=self.callable
    )
