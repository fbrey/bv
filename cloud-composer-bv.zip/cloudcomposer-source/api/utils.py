from abc import ABC
from typing import Callable
import logging

from pydantic import BaseModel

from functools import wraps



class ModelPopulatedByFieldName(BaseModel, ABC):
  class Config:
    allow_population_by_field_name = True


class CustomDictModel(BaseModel, ABC):
  def dict(self, **kwargs):
    # TODO: mudar para usar o exclude na hora de transformar para dict.
    hidden_fields = set(
      attribute_name
      for attribute_name, model_field in self.__fields__.items()
      if model_field.field_info.extra.get('hidden') is True
    )
    kwargs.setdefault('exclude', hidden_fields)

    if 'first_letter_lower' in kwargs:
      if kwargs['first_letter_lower']:
        for _, field in self.__fields__.items():
          field.alias = f'{field.alias[0].lower()}{field.alias[1:]}'

      del kwargs['first_letter_lower']
    
    return super().dict(**kwargs)


class ArbitraryTypeModel(BaseModel):
  class Config:
    arbitrary_types_allowed = True


def log_return(original_function: Callable):
  @wraps(original_function)
  def inner(*args: tuple, **kwargs: dict) -> Callable:
    result = original_function(*args, **kwargs)
    logging.info(f'Query gerada: {result}')
    return result
  return inner
