from __future__ import annotations

from typing import List
from abc import ABC
from abc import abstractmethod

from pypattyrn.creational.factory import Factory
from airflow.utils.task_group import TaskGroup
from airflow.models.dag import DAG

from models import DagDefaultArguments
from models import DagArguments
from models import Contract
from tasks import TaskFactory
from enums import TaskTypes
from enums import DagTypes



class DagFactory(Factory):
  def create(self, dag_type: DagTypes):
    dags = {
      DagTypes.ReprocessingDag: ReprocessingDag,
      DagTypes.IngestionDag: IngestionDag,
      DagTypes.IngestionSFTPDag: IngestionSFTPDag,
      DagTypes.IngestionSSHDag: IngestionSSHDag,
    }
    dag_constructor = dags[dag_type]
    return dag_constructor()


class BaseDag(ABC):
  def __init__(self, contract: Contract):
    self.factory = TaskFactory(contract)
    self.airflow = contract.airflow
    self.application = contract.application
    self.dataflow = contract.dataflow
    
    DagArguments.update_forward_refs()
    self.arguments = DagArguments(
      default_args=DagDefaultArguments(
        start_date=contract.airflow.start_date,
        email=contract.airflow.email
      ),
      schedule_interval=contract.airflow.cron_scheduler,
      table_name=contract.dataflow.pipeline.table_name,
      tags=self.tags
    )

  @property
  @abstractmethod
  def tags(self) -> List[str]:
    raise NotImplementedError()
  
  @property
  @abstractmethod
  def dag(self) -> DAG:
    raise NotImplementedError()


class NonFileDag(BaseDag):
  @property
  def dag(self) -> DAG:
    with DAG(**self.arguments.dict()) as dag:
      start_dag = self.factory.create(TaskTypes.START)

      with TaskGroup(group_id='create_tables') as create_tables:
        create_raw_table = self.factory.create(TaskTypes.EXTERNAL_TABLE)
        create_trusted_table = self.factory.create(TaskTypes.CREATE_TRUSTED_TABLE)
        create_raw_table >> create_trusted_table

      # # TODO: tem que testar esse fluxo do ingestion_group
      # with TaskGroup(group_id='ingest_raw_data') as ingestion_group:
      #   raw_task = self.factory.create(TaskTypes.RAW_INGESTION)
      #   call_ingestion_runner = self.factory.create(task_type=TaskTypes.RAW_INGESTION, parms=dict(raw_step=raw_task))

      with TaskGroup(group_id='transform_trusted_data') as transform_trusted_group:
        branch_task = self.factory.create(TaskTypes.LOAD_TYPE_BRANCH)
        trusted_full = self.factory.create(TaskTypes.LOAD_TRUSTED_FULL)
        trusted_incremental = self.factory.create(TaskTypes.LOAD_TRUSTED_INCREMENTAL)

        trusted_load = self.factory.create(TaskTypes.TRUSTED_LOAD)
        publish_success_task = self.factory.create(TaskTypes.PUBLISH_SUCCESS_OPERATOR)
        publish_fail_task = self.factory.create(TaskTypes.PUBLISH_FAIL_OPERATOR)
        branch_task >> [trusted_full, trusted_incremental] >> trusted_load >> [publish_success_task, publish_fail_task]

      end_dag = self.factory.create(TaskTypes.END)

      # start_dag >> ingestion_group >> create_tables >> transform_trusted_group >> end_dag
      start_dag >> create_tables >> transform_trusted_group >> end_dag
    return dag


class ReprocessingDag(NonFileDag):
  @property
  def tags(self) -> List[str]:
    return ['reprocessamento']


class IngestionDag(NonFileDag):
  @property
  def tags(self) -> List[str]:
    return ['ingestao']


class FileDag(BaseDag):
  @property
  def dag(self) -> DAG:
    with DAG(**self.arguments.dict()) as dag:
      start_dag = self.factory.create(TaskTypes.START)

      with TaskGroup(group_id='file_processing') as ssh_group:
        move_files_from_ssh_to_gcs = self.factory.create(TaskTypes.MOVE_FILES_FROM_SSH_TO_GCS)
        branch_decompress = self.factory.create(TaskTypes.LOAD_BRANCH_COMPRESS)
        dataflow_decompress_job = self.factory.create(TaskTypes.SFTP_DATAFLOW_DECOMPRESS_JOB) # TODO: TESTAR NO AMBIENTE BV
        move_files_to_raw = self.factory.create(TaskTypes.SFTP_MOVE_FILES_TO_RAW)
        move_files_from_ssh_to_gcs >> branch_decompress >> [dataflow_decompress_job, move_files_to_raw]

      # with TaskGroup(group_id='create_tables') as create_tables:
      #   create_raw_table = self.factory.create(TaskTypes.EXTERNAL_TABLE_SFTP)
      #   create_trusted_table = self.factory.create(TaskTypes.CREATE_TRUSTED_TABLE)
      #   create_raw_table >> create_trusted_table

      with TaskGroup(group_id='transform_trusted_data') as transform_trusted_group:
        trusted_full = self.factory.create(TaskTypes.LOAD_TRUSTED_FULL)
        trusted_incremental = self.factory.create(TaskTypes.LOAD_TRUSTED_INCREMENTAL)
        branch_task = self.factory.initialize(TaskTypes.LOAD_TYPE_BRANCH)
        branch_trusted_load = self.factory.create(TaskTypes.LOAD_TYPE_BRANCH, parms=dict(branch=branch_task))
        trusted_load = self.factory.create(TaskTypes.TRUSTED_LOAD)
        publish_success_task = self.factory.create(TaskTypes.PUBLISH_SUCCESS_OPERATOR)
        publish_fail_task = self.factory.create(TaskTypes.PUBLISH_FAIL_OPERATOR)
        branch_trusted_load >> [trusted_full, trusted_incremental] >> trusted_load >> [publish_success_task, publish_fail_task]

      end_dag = self.factory.create(TaskTypes.END)
      # start_dag >> ssh_group >> create_tables >> transform_trusted_group >> end_dag

    return dag


class IngestionSFTPDag(FileDag):
  @property
  def tags(self) -> List[str]:
    return [
      'ingestao', 
      f'orquestrador-pipeline-versao-{self.application.dag_template_version}', 
      f'motor-ingestao-versao-{self.dataflow.infra.template_version}'
    ]


class IngestionSSHDag(IngestionSFTPDag):
  ...
